import React from 'react'
import './FooterAuth.css'


const SmallFooter = () => {
  return (
    <>
      <div className="SmallFooter-container">
         <span>2021 <span style={{fontSize : "14px"}}>&#169;</span> Laundry</span>
      </div>
    </>
  )
}

export default SmallFooter